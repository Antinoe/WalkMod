using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;

namespace WalkMod.Buffs
{
    public class Walk : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Walking");
            Description.SetDefault("You are moving slower.");
            Main.buffNoTimeDisplay[Type] = false;
            Main.debuff[Type] = false;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            //if (!npc.boss)
			{
				//npc.velocity.X = npc.velocity.X * 0.9f;
				player.velocity.X = player.velocity.X * 0.925f;
			}
        }
    }
}
