﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace WalkMod
{
    public class WalkPlayer : ModPlayer
    {	
		public bool walk;
		
		public static WalkPlayer ModPlayer(Player player)
		{
			return player.GetModPlayer<WalkPlayer>();
		}

		/*public override void ResetEffects() {
			walk = false;
		}*/
		
		/*public override void UpdateAccessory(Player player, bool hideVisual) {
				player.GetModPlayer<WalkPlayer>().walk = true;
			}*/
		
		public override void PostUpdate()
		{
			if (walk)
			{
				player.velocity.X *= 0.925f;
			}
			if (!walk)
			{
				player.velocity.X *= 1f; 
			}
			if (WalkMod.Walk.JustPressed)
			{
				{
					walk = !walk;
					//player.AddBuff(ModContent.BuffType<Buffs.Walk>(), 9999);
				}
			}
		}
		
		/*public override void ProcessTriggers(TriggersSet triggersSet)
		{
			if (WalkMod.Walk.JustPressed)
			{
				{
					walk = !walk;
					//player.AddBuff(ModContent.BuffType<Buffs.Walk>(), 9999);
				}
			}
		}*/
    }
}
