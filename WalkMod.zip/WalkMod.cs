using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;


namespace WalkMod
{
	public class WalkMod : Mod
	{
		public static ModHotKey Walk;
		
        public override void Load()
        {
            Walk = RegisterHotKey("Walk", "Y");
        }
        
        public override void Unload()
        {
            Walk = null;
        }
    }
}
